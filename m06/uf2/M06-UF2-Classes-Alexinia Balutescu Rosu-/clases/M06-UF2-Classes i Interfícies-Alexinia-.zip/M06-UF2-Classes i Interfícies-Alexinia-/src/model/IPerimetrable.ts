export interface IPerimetrable {
    perimetre() : number;
}